import { UploadZone } from "@/components/UploadZone";
import { PhotoStack } from "@/components/PhotoStack";

export default function HomePage() {
  return (
    <div className="mx-auto flex max-w-3xl flex-col items-center px-6 pb-32 pt-10 text-center sm:pt-16">
      <span className="glass-thin animate-fade-up rounded-full border border-gold/25 px-4 py-1 text-[12px] font-medium tracking-wide text-gold">
        Twelve years led here
      </span>

      <h1
        className="type-hero mt-7 animate-fade-up text-balance text-ink dark:text-white"
        style={{ animationDelay: "80ms" }}
      >
        Every memory,
        <br />
        kept in one place.
      </h1>

      <p
        className="type-body mt-5 max-w-lg animate-fade-up text-[17px] text-smoke sm:text-[19px]"
        style={{ animationDelay: "160ms" }}
      >
        As we close this chapter, add the photos that made it ours — the
        friends, the classrooms, the last days that felt like forever.
      </p>

      <div className="mt-10 w-full animate-fade-up" style={{ animationDelay: "200ms" }}>
        <PhotoStack />
      </div>

      <div className="mt-10 w-full animate-fade-up" style={{ animationDelay: "240ms" }}>
        <UploadZone />
      </div>

      <p className="type-caption mt-10 animate-fade-up text-smoke/80" style={{ animationDelay: "300ms" }}>
        Everything you add here shows up on{" "}
        <span className="font-medium text-ink dark:text-white">The Wall</span>{" "}
        for everyone to see — and leave a Pathivu on.
      </p>
    </div>
  );
}
